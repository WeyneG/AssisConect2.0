package com.assisconnect.backend.api;

import java.util.List;

public class AlocarRequest {
    private List<Long> idosoIds;

    public List<Long> getIdosoIds() { return idosoIds; }
    public void setIdosoIds(List<Long> idosoIds) { this.idosoIds = idosoIds; }
}
