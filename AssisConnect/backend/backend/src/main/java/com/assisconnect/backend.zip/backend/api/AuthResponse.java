package com.assisconnect.backend.api;

public record AuthResponse(String token, String name, String email) {}
